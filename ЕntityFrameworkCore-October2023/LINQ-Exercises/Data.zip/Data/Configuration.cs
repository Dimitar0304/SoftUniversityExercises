﻿namespace MusicHub.Data
{
    public static class Configuration
    {
        public static string ConnectionString =
            @"Server=DESKTOP-S4CE7G8\SQLEXPRESS;Database=MusicHub;
Integrated Security=True;Trusted_Connection=True";
    }
}
