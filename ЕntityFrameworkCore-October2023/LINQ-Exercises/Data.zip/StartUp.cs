﻿namespace MusicHub
{
    using System;
    using System.Text;
    using Data;
    using Initializer;
    using Microsoft.EntityFrameworkCore;
    using MusicHub.Data.Models;

    public class StartUp
    {
        public static void Main()
        {
            MusicHubDbContext context =
                new MusicHubDbContext();

            // DbInitializer.ResetDatabase(context);

            //Test your solutions here
            Console.WriteLine(ExportSongsAboveDuration(context, 4));
        }

        public static string ExportAlbumsInfo(MusicHubDbContext context, int producerId)
        {
            var albumInfo = context.Producers
                .Include(a => a.Albums)
                .ThenInclude(x => x.Songs)
                .ThenInclude(x => x.Writer)
                .Where(p => p.Id == producerId)
                .Select(x => new
                {
                    ProducerName = x.Name,
                    AlbumSongs = x.Albums.Select(a => new
                    {
                        AlbumName = a.Name,
                        ReleaseDate = a.ReleaseDate,
                        Songs = a.Songs
                        .Select(s => new
                        {
                            SongName = s.Name,
                            SongPrice = s.Price,
                            SongWirterName = s.Writer.Name
                        }).OrderByDescending(s => s.SongName).ThenBy(s => s.SongWirterName).ToList(),
                        AlbumPrice = a.Price
                    })

                }).First();
            StringBuilder sb = new StringBuilder();

            foreach (var a in albumInfo.AlbumSongs.OrderByDescending(a => a.AlbumPrice))
            {

                sb.AppendLine($"-AlbumName: {a.AlbumName}");
                sb.AppendLine($"-ReleaseDate: {a.ReleaseDate.ToString("MM/dd/yyyy")}");
                sb.AppendLine($"-ProducerName: {albumInfo.ProducerName}");
                int counter = 1;
                sb.AppendLine($"-Songs:");
                foreach (var s in a.Songs)
                {
                    sb.AppendLine($"---#{counter++}");
                    sb.AppendLine($"---SongName: {s.SongName}");
                    sb.AppendLine($"---Price: {s.SongPrice:F2}");
                    sb.AppendLine($"---Writer: {s.SongWirterName}");
                }
                sb.AppendLine($"-AlbumPrice: {a.AlbumPrice:f2}");
            }

            return sb.ToString().TrimEnd();





        }

        public static string ExportSongsAboveDuration(MusicHubDbContext context, int duration)
        {
            var songs = context.Songs
                .Include(s => s.SongPerformers)
                .ThenInclude(sp => sp.Performer)
                .Include(s => s.Writer)
                .Include(s => s.Album)
                .ThenInclude(a=>a.Producer)
                .ToList()
                .Where(s => s.Duration.TotalSeconds > duration)
                .Select(s => new
                {
                    s.Name,
                    Performers = s.SongPerformers
                    .Select(sp => new { PerformerName = sp.Performer.FirstName + " " + sp.Performer.LastName })
                    .OrderBy(sp=>sp.PerformerName)
                    .ToList(),
                    SongWriterName = s.Writer.Name,
                    AlbumProducerName = s.Album.Producer.Name,
                    Duration = s.Duration.ToString("c"),



                }).OrderBy(s => s.Name)
                .ThenBy(s => s.SongWriterName)
                .ToList();
                

            StringBuilder sb = new StringBuilder();
                int counter = 1;
            foreach (var s in songs)
            {
                sb.AppendLine($"-Song #{counter++}");
                sb.AppendLine($"---SongName: {s.Name}");
                sb.AppendLine($"---Writer: {s.SongWriterName}");
                if (s.Performers.Any())
                {

                  
                    foreach (var p in s.Performers)
                    {
                       
                        sb.AppendLine($"---Performer: {string.Join(',', p.PerformerName)}");
                    }
                }
                else
                {
                    sb.AppendLine($"---Performer");
                }
               
                sb.AppendLine($"---AlbumProducer: {s.AlbumProducerName}");
                sb.AppendLine($"---Duration: {s.Duration}");
            }
            return sb.ToString().Trim();

        }
    }
}
