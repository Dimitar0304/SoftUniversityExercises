﻿namespace BookShop
{
    using BookShop.Models;
    using BookShop.Models.Enums;
    using Data;
    using Initializer;
    using Microsoft.Data.SqlClient.Server;
    using Microsoft.EntityFrameworkCore;
    using Microsoft.VisualBasic;
    using System.Linq;
    using System.Net.Http.Headers;
    using System.Text;
    using static System.Reflection.Metadata.BlobBuilder;

    public class StartUp
    {
        public static void Main()
        {
            using var db = new BookShopContext();
            //string input = Console.ReadLine();
            // int lenght = int.Parse(Console.ReadLine());
            Console.WriteLine( RemoveBooks(db));
            // DbInitializer.ResetDatabase(db);
        }
        public static string GetBooksByAgeRestriction(BookShopContext context, string command)
        {
            int ageResInt;
            command = command.ToLower();
            if (command == "minor")
            {
                ageResInt = 0;
            }
            else if (command == "teen")
            {
                ageResInt = 1;
            }
            else
            {
                ageResInt = 2;
            }

            var bookTitles = context.Books
                .Select(b => new { b.Title, b.AgeRestriction })
               .Where(b => (int)b.AgeRestriction == ageResInt)
                .OrderBy(b => b.Title)
                .ToList();



            StringBuilder sb = new StringBuilder();
            foreach (var t in bookTitles)
            {
                sb.AppendLine(t.Title);

            }
            return sb.ToString().TrimEnd();
        }
        public static string GetBooksByPrice(BookShopContext context)
        {
            var bookTitles = context.Books.Where(b => b.Price > 40)
                .OrderByDescending(b => b.Price)
                .ToList();
            StringBuilder sb = new StringBuilder();
            foreach (var t in bookTitles)
            {
                sb.AppendLine($"{t.Title} - ${t.Price:F2}");
            }
            return sb.ToString().TrimEnd();
        }
        public static string GetGoldenBooks(BookShopContext context)
        {
            var books = context.Books.Where(b => b.Copies < 5000 && (int)b.EditionType == 2)
                .OrderBy(b => b.BookId)
                .ToList();
            StringBuilder sb = new StringBuilder();
            foreach (var b in books)
            {
                sb.AppendLine($"{b.Title}");
            }
            return sb.ToString().TrimEnd();
        }
        public static string GetBooksNotReleasedIn(BookShopContext context, int year)
        {
            var books = context.Books.Where(b => b.ReleaseDate.Value.Year != year)
                .OrderBy(b => b.BookId)
                .ToList();
            StringBuilder sb = new StringBuilder();
            foreach (var b in books)
            {
                sb.AppendLine($"{b.Title}");
            }
            return sb.ToString().TrimEnd();

        }
        public static string GetBooksByCategory(BookShopContext context, string input)
        {
            List<string> categoryList = input.ToLower().Split().ToList();

            var books = context.BooksCategories
                .Where(bc => categoryList.Contains(bc.Category.Name.ToLower()))
                .Select(b => b.Book.Title)
                .OrderBy(b => b)
                .ToList();

            StringBuilder sb = new StringBuilder();
            foreach (var b in books)
            {
                sb.AppendLine($"{b}");
            }
            return sb.ToString().TrimEnd();
        }
        public static string GetBooksReleasedBefore(BookShopContext context, string date)
        {
            DateTime dateTime = DateTime.Parse(date);
            // dateTime = dateTime.GetDateTimeFormats().;

            DateTime parsedDate = DateTime.ParseExact(date, "dd-MM-yyyy", null);

            //Finding the Books
            var books = context.Books
                .Where(b => b.ReleaseDate < parsedDate)
                .Select(b => new { b.Title, b.EditionType, b.Price, b.ReleaseDate })
                .OrderByDescending(b => b.ReleaseDate);
            StringBuilder sb = new StringBuilder();
            foreach (var b in books)
            {
                sb.AppendLine($"{b.Title} - {b.EditionType} - ${b.Price:f2}");
            }
            return sb.ToString().TrimEnd();
        }
        public static string GetAuthorNamesEndingIn(BookShopContext context, string input)
        {
            var authors = context.Authors.Where(a => a.FirstName.EndsWith(input))
                .Select(a => new { FullName = a.FirstName + " " + a.LastName })
                .OrderBy(b => b.FullName)
                .ToList();

            StringBuilder stringBuilder = new StringBuilder();
            foreach (var a in authors)
            {
                stringBuilder.AppendLine(a.FullName);
            }
            return stringBuilder.ToString().TrimEnd();
        }
        public static string GetBookTitlesContaining(BookShopContext context, string input)
        {
            input = input.ToLower();
            var titles = context.Books
                .Where(b => b.Title.ToLower().Contains(input))
                .OrderBy(b => b.Title)
                .ToList();
            StringBuilder sb = new StringBuilder();
            foreach (var t in titles)
            {
                sb.AppendLine(t.Title);
            }
            return sb.ToString().TrimEnd();
        }
        public static string GetBooksByAuthor(BookShopContext context, string input)
        {
            var books = context.Books
                .Where(b => b.Author.LastName.ToLower().StartsWith(input.ToLower()))
                .Select(b => new
                {
                    AuthorFullName = b.Author.FirstName + " " + b.Author.LastName
                ,
                    b.BookId,
                    b.Title
                })
                .OrderBy(b => b.BookId)
                .ToList();

            StringBuilder sb = new StringBuilder();
            foreach (var b in books)
            {
                sb.AppendLine($"{b.Title} ({b.AuthorFullName})");
            }
            return sb.ToString().TrimEnd();
        }
        public static int CountBooks(BookShopContext context, int lengthCheck)
        {
            var result = context.Books
                .Where(b => b.Title.Length > lengthCheck)
                .ToList();
            return result.Count;
        }
        public static string CountCopiesByAuthor(BookShopContext context)
        {
            var copiesByAuthor = context.Authors
                .Select(b => new
                {
                    AuthorFullName = b.FirstName + " " + b.LastName,
                    CountOfCopies = b.Books.Sum(b => b.Copies)
                })
                .OrderByDescending(b => b.CountOfCopies)
                .ToList();
            StringBuilder sb = new StringBuilder();
            foreach (var a in copiesByAuthor)
            {
                sb.AppendLine($"{a.AuthorFullName} - {a.CountOfCopies}");
            }
            return sb.ToString().TrimEnd();
        }
        public static string GetTotalProfitByCategory(BookShopContext context)
        {
            var categoriesAndProfit = context.Categories.Include(c => c.CategoryBooks)
                .ThenInclude(c => c.Book)
                .Select(cp => new
                {
                    CategoryName = cp.Name,
                    Profit = cp.CategoryBooks.Sum(cb => cb.Book.Price * cb.Book.Copies)
                })
                .OrderByDescending(cp => cp.Profit)
                .ThenBy(cp => cp.CategoryName)
                .ToList();
            StringBuilder sb = new StringBuilder();
            foreach (var cp in categoriesAndProfit)
            {
                sb.AppendLine($"{cp.CategoryName} ${cp.Profit:f2}");


            }
            return sb.ToString().TrimEnd();

        }
        public static string GetMostRecentBooks(BookShopContext context)
        {
            var mostRecentBooks = context.Categories
                .Include(c => c.CategoryBooks)
                .ThenInclude(c => c.Book)
                .Select(c => new
                {
                    CategoryName = c.Name,
                    //top 3 books
                    MostRecentBooks = c.CategoryBooks
                    .Select(cb => new
                    {
                        cb.Book.ReleaseDate,
                        cb.Book.Title,
                        cb.Book.Copies
                    })
                    .OrderByDescending(cb => cb.ReleaseDate)
                    .Take(3)
                    .ToList()
                }).OrderBy(c=>c.CategoryName)
                .ToList();

               
            StringBuilder sb = new StringBuilder();
            foreach (var cb in mostRecentBooks)
            {
                sb.AppendLine($"--{cb.CategoryName}");
                foreach (var book in cb.MostRecentBooks)
                {
                    sb.AppendLine($"{book.Title} ({book.ReleaseDate.Value.Year})");
                }
            }
            return sb.ToString().TrimEnd();
        }
        public static void IncreasePrices(BookShopContext context)
        {
            var books = context.Books.Where(b => b.ReleaseDate.Value.Year < 2010)
                .ToList();

            foreach (var b in books)
            {
                b.Price += 5;
            }
        }
        public static int RemoveBooks(BookShopContext context)
        {
            var booksForRemove = context.Books
                .Where(b => b.Copies < 4200)
                .ToList();
            var booksForRemoveFromMapingTable = context.BooksCategories
                .Where(bc => bc.Book.Copies < 4200)
                .ToList();

           context.RemoveRange(booksForRemoveFromMapingTable);
            context.RemoveRange(booksForRemove);
            context.SaveChanges();

           
            return booksForRemove.Count;
                
        }
    }

}


