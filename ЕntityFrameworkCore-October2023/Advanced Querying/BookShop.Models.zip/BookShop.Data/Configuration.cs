﻿namespace BookShop.Data
{
    internal class Configuration
    {
        internal static string ConnectionString
            => "Server=DESKTOP-S4CE7G8\\SQLEXPRESS;Database=BookShop;Integrated Security=True;";
    }
}
