﻿


using Microsoft.EntityFrameworkCore;
using SoftUni.Data;
using SoftUni.Models;
using System.ComponentModel;
using System.Globalization;
using System.Text;

public class StartUp
{
    public static void Main()
    {
        var context = new SoftUniContext();


        Console.WriteLine(GetEmployeesFullInformation(context));
        

    }
    public static string GetEmployeesFullInformation(SoftUniContext context)
    {
        var result = context.Employees
            .Select(e => new { e.FirstName, e.LastName, e.MiddleName, e.JobTitle, e.Salary })
            .ToList();

        StringBuilder sb = new StringBuilder();
        foreach (var employee in result)
        {
            sb.AppendLine($"{employee.FirstName} {employee.LastName} {employee.MiddleName}" +
                $" {employee.JobTitle} {employee.Salary:f2}");
        }
        return sb.ToString().Trim();
    }
    public static string GetEmployeesWithSalaryOver50000(SoftUniContext context)
    {
        var employees = context.Employees
            .Select(e => new { e.FirstName, e.Salary })
            .Where(e => e.Salary > 50000)
            .OrderBy(e => e.FirstName)
            .ToList();
        StringBuilder sb = new StringBuilder();
        foreach (var e in employees)
        {
            sb.AppendLine($"{e.FirstName} - {e.Salary:f2}");
        }
        return sb.ToString().Trim();
    }

    public static string GetEmployeesFromResearchAndDevelopment(SoftUniContext context)
    {
        var employees = context.Employees
            .Select(e => new { e.FirstName, e.LastName, DepartmentName = e.Department.Name, e.Salary })
            .Where(d => d.DepartmentName == "Research and Development")
            .OrderBy(e => e.Salary)
            .ThenByDescending(e => e.FirstName)
            .ToList();
        StringBuilder sb = new StringBuilder();
        foreach (var employee in employees)
        {
            sb.AppendLine($"{employee.FirstName} " +
                $"{employee.FirstName} {employee.LastName} from Research and Development - ${employee.Salary:f2}");
        }
        return sb.ToString().Trim();
    }

    public static string AddNewAddressToEmployee(SoftUniContext context)
    {
        var adress = new Address();
        adress.AddressText = "Vitoshka 15";
        adress.TownId = 4;

        context.Addresses.Add(adress);
        context.SaveChanges();

        var nakov = context.Employees.Where(e => e.LastName == "Nakov").FirstOrDefault();

        nakov.Address = adress;
        context.SaveChanges();

        var employees = context.Employees.Select(e => new { e.AddressId, e.Address })
            .OrderByDescending(e => e.AddressId)
            .Take(10);

        StringBuilder sb = new StringBuilder();
        foreach (var e in employees)
        {
            sb.AppendLine($"{e.Address.AddressText}");
        }
        return sb.ToString().Trim();

    }
    public static string GetEmployeesInPeriod(SoftUniContext context)
    {
        var employees = context.Employees.Take(10)
            .Select(e => new
            {
                e.FirstName,
                e.LastName,
                managerFirstName = e.Manager.FirstName,
                managerLastName = e.Manager.LastName,
                project =
                 e.EmployeesProjects
                 .Where(ep => ep.Project.StartDate.Year >= 2001 & ep.Project.StartDate.Year <= 2003)
                 .Select(ep => new
                 {
                     projectName = ep.Project.Name,
                     startDate = ep.Project.StartDate.ToString("M/d/yyyy h:mm:ss tt", CultureInfo.InvariantCulture),
                     endDate = ep.Project.EndDate != null
                 ? ep.Project.EndDate.Value.ToString("M/d/yyyy h:mm:ss tt", CultureInfo.InvariantCulture)
                 : "not finished"
                 })
            }).ToList();
        StringBuilder sb = new StringBuilder();
        foreach (var e in employees)
        {
            sb.AppendLine($"{e.FirstName} {e.LastName} - Manager: {e.managerFirstName} {e.managerLastName}");
            if (e.project.Any())
            {

                foreach (var p in e.project)
                {
                    sb.AppendLine(String.Join(Environment.NewLine, e.project
                         .Select(p => $"--{p.projectName} - {p.startDate} - {p.endDate}")));

                }
            }
        }
        return sb.ToString().Trim();
    }

    public static string GetAddressesByTown(SoftUniContext context)
    {
        var addresses = context.Addresses
         .OrderByDescending(a => a.Employees.Count)
            .ThenBy(a => a.Town.Name)
            .ThenBy(a => a.AddressText)
            .Take(10)
            .Select(a => $"{a.AddressText}, {a.Town.Name} - {a.Employees.Count} employees")
            .ToList();



        return string.Join(Environment.NewLine, addresses);
    }
    public static string GetEmployee147(SoftUniContext context)
    {
        var employeeInfo = context.Employees
            .Where(e => e.EmployeeId == 147)
            .
            Select(e => new
            {
                e.FirstName,
                e.LastName,
                e.JobTitle,
                e.EmployeeId,
                projects = e.EmployeesProjects.Where(ep => ep.EmployeeId == 147)
                .Select(ep => new { ProjectName = ep.Project.Name })
                .OrderBy(ep => ep.ProjectName)
                .ToList()
            })
            .FirstOrDefault();
        StringBuilder sb = new StringBuilder();

        sb.AppendLine($"{employeeInfo.FirstName} {employeeInfo.LastName} - {employeeInfo.JobTitle}");
        foreach (var p in employeeInfo.projects)
        {
            sb.AppendLine(p.ProjectName);
        }

        return sb.ToString().Trim();
    }

    public static string GetDepartmentsWithMoreThan5Employees(SoftUniContext context)
    {
        var departments = context.Departments.Where(d => d.Employees.Count > 5)
            .Select(d => new
            {
                d.Name,
                d.Manager.FirstName,
                d.Manager.LastName,
                EmployeesCount = d.Employees.Count,
                EmployeesInfo = d.Employees.Select(e => new
                {
                    e.FirstName,
                    e.LastName,
                    e.JobTitle

                }).OrderBy(e => e.FirstName).ThenBy(e => e.LastName).ToList()
            })
            .OrderBy(d => d.EmployeesCount)
            .ThenBy(d => d.Name)
            .ToList();
        StringBuilder sb = new StringBuilder();

        foreach (var d in departments)
        {
            sb.AppendLine($"{d.Name} – {d.FirstName} {d.LastName}");
            foreach (var e in d.EmployeesInfo)
            {
                sb.AppendLine($"{e.FirstName} {e.LastName} - {e.JobTitle}");
            }
        }
        return sb.ToString().Trim();
    }

    public static string GetLatestProjects(SoftUniContext context)
    {
        var projects = context.Projects.OrderByDescending(p => p.StartDate).Take(10)
            .OrderBy(p => p.Name)
            .Select(p => new
            {
                p.Name,
                p.StartDate,
                p.Description
            })
            .ToList();


        StringBuilder sb = new StringBuilder();
        foreach (var p in projects)
        {
            sb.AppendLine($"{p.Name}");
            sb.AppendLine($"{p.Description}");
            sb.AppendLine($"{p.StartDate}");
        }
        return sb.ToString().TrimEnd();
    }

    public static string IncreaseSalaries(SoftUniContext context)
    {
        decimal salaryModifier = 1.12m;
        string[] departmentNames = new string[] { "Engineering", "Tool Design", "Marketing", "Information Services" };

        var employeesForSalaryIncrease = context.Employees
            .Where(e => departmentNames.Contains(e.Department.Name))
            .ToArray();

        foreach (var e in employeesForSalaryIncrease)
        {
            e.Salary *= salaryModifier;
        }

        context.SaveChanges();

        string[] emplyeesInfoText = context.Employees
            .Where(e => departmentNames.Contains(e.Department.Name))
            .OrderBy(e => e.FirstName)
            .ThenBy(e => e.LastName)
            .Select(e => $"{e.FirstName} {e.LastName} (${e.Salary:f2})")
            .ToArray();

        return string.Join(Environment.NewLine, emplyeesInfoText);
    }

    public static string GetEmployeesByFirstNameStartingWithSa(SoftUniContext context)
    {
        string[] employeesInfoText = context.Employees
            .Where(e => e.FirstName.Substring(0, 2).ToLower() == "sa")
            .OrderBy(e => e.FirstName)
            .ThenBy(e => e.LastName)
            .Select(e => $"{e.FirstName} {e.LastName} - {e.JobTitle} - (${e.Salary:f2})")
            .ToArray();

        return string.Join(Environment.NewLine, employeesInfoText);



    }

    public static string DeleteProjectById(SoftUniContext context)
    {
        var projectsWithIds2 = context.EmployeesProjects.Where(ep => ep.ProjectId == 2);
        context.EmployeesProjects.RemoveRange(projectsWithIds2);
        context.SaveChanges();
        var project = context.Projects.Where(e => e.ProjectId == 2).FirstOrDefault();
        context.Projects.Remove(project);
        context.SaveChanges();

        var projects = context.Projects.Take(10);
        StringBuilder sb = new StringBuilder();

        foreach (var p in projects)
        {
            sb.AppendLine(p.Name);
        }

        return sb.ToString().TrimEnd();
    }


}