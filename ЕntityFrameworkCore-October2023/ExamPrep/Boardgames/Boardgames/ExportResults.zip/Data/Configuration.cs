﻿namespace Boardgames.Data
{
    public static class Configuration
    {
        public static string ConnectionString = @"Server=DESKTOP-S4CE7G8\SQLEXPRESS;Database=Boardgames;Integrated Security=True;Encrypt=False";
    }
}
