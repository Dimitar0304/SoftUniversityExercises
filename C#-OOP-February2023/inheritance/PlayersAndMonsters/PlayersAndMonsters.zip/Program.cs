﻿namespace PlayersAndMonsters
{
    public class StartUp
    {
        public static void Main(string[] args)
        {
            SoulMaster soulmaster = new SoulMaster("mitkaaoao",100);
            Console.WriteLine(soulmaster);
        }
    }
}