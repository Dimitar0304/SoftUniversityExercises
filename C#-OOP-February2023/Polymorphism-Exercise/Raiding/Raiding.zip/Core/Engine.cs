﻿using Raiding.Core.Interfaces;
using Raiding.Factories;
using Raiding.Factories.Interfaces;
using Raiding.IO.Interfaces;
using Raiding.Models.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Raiding.Core
{
    public class Engine : IEngine
    {
        private IReader reader;
        private IWriter writer;
        private IBaseHeroFactory heroFactory = new BaseHeroFactory();
        private ICollection<IBaseHero> heroes;

        public Engine(IReader reader, IWriter writer)
        {
            this.reader = reader;
            this.writer = writer;
            heroes = new List<IBaseHero>();
        }

        public void Run()
        {
            int countOfHeroes = int.Parse(reader.ReadLine());
            try
            {

                for (int i = 0; i < countOfHeroes; i++)
                {
                    string heroName = reader.ReadLine();
                    string type = reader.ReadLine();
                    heroes.Add(heroFactory.Create(type, heroName));

                }
            }
            catch (Exception ex )
            {

                Console.WriteLine(ex.Message); ;
            }
         
            int bossPower = int.Parse(reader.ReadLine());
            int sumOfHeroPowers = 0;
            foreach (var hero in heroes)
            {
                sumOfHeroPowers += hero.Power;
                Console.WriteLine(hero.CastAbility());
            }
            if (sumOfHeroPowers > bossPower)
            {
                writer.WriteLine("Victory!");
            }
            else
            {
                writer.WriteLine("Defeat...");
            }
        }
    }
}
